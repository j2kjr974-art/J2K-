# J2K' Launcher v0.3.0

Projet Android natif Kotlin + Jetpack Compose. Android 11+ (minSdk 30).

## Compilation
1. Ouvrir ce dossier dans Android Studio récent avec JDK 17.
2. Attendre la synchronisation Gradle.
3. Utiliser **Build > Build APK(s)**.
4. APK debug : `app/build/outputs/apk/debug/app-debug.apk`.

## Fonctions de cette version
- Interface noire/verte avec Accueil, Versions, Mods et Paramètres.
- Profils SA-MP 0.3.7 et 0.3.DL, clients installés séparément.
- Lancement via l'identifiant de package configuré.
- Sélection persistante du dossier GTA par Storage Access Framework.
- Import de ZIP avec rejet des chemins `..` et chemins absolus.
- Import récursif de dossiers déjà extraits via SAF.
- Installation des fichiers du pack dans le dossier GTA sélectionné.
- Sauvegarde des fichiers existants dans l'espace privé de l'application.
- Restauration des fichiers sauvegardés ou suppression des fichiers ajoutés par le pack.
- Blocage des conflits entre chemins de packs déjà actifs.
- Suppression d'un pack installé interdite tant qu'il n'a pas été restauré.

## Format des packs
Les chemins des fichiers à la racine du pack sont relatifs au dossier GTA sélectionné.
Exemple :
```
MonPack/
  j2k.properties
  models/
    txd/
      vehicle.txd
  data/
    handling.cfg
```
`j2k.properties` est facultatif et peut contenir :
```
category=vehicules
```
Les fichiers de métadonnées J2K sont ignorés pendant l'installation. Le contenu du pack doit être organisé exactement selon les chemins attendus par le jeu.

## Limites et précautions
- Le projet fournit un gestionnaire de fichiers générique. Il ne connaît pas automatiquement le format spécifique de chaque mod : le créateur du pack doit respecter l'arborescence cible.
- SAF ne permet d'écrire que dans les emplacements réellement autorisés par Android et le fournisseur de documents. Android peut interdire `Android/data` ou `Android/obb`. Le launcher ne contourne pas ces protections.
- Une opération d'installation utilise une sauvegarde par pack et effectue un rollback au mieux si une écriture échoue. Pour une fiabilité maximale, tester d'abord sur une copie du dossier du jeu.
- Le lancement utilise les packages renseignés. Le package `com.sampmobilerp.game` est proposé par défaut pour le client 0.3.7 reçu ; confirme-le dans les paramètres si le bouton JOUER ne trouve pas le client. Le package de la version 0.3.DL reste configurable séparément.
- Les champs pseudo et serveur sont conservés dans les paramètres du launcher ; leur injection dans SA-MP nécessite une interface officiellement prise en charge par le client.
- Les APK SA-MP ne sont pas inclus. Utiliser uniquement des fichiers distribués légalement et compatibles avec le jeu.


## Adaptation au client reçu
- Le projet est préconfiguré avec `com.sampmobilerp.game` comme identifiant supposé du client SA-MP 0.3.7 reçu (repéré dans les chaînes DEX). Le manifeste binaire n’a pas pu être décodé dans cet environnement : vérifie le package réel dans les paramètres Android si nécessaire.
- L’APK du client n’est pas fusionné ou repackagé : J2K’ Launcher le démarre s’il est installé sur le téléphone.
